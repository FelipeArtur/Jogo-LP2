package com.felipe.lapajogo;

import java.io.IOException;

public class APP {
    public static void main(String[] args) throws IOException{

        Batalha iniciar = new Batalha();
        
        iniciar.batalha();

    }
    
}   
    

